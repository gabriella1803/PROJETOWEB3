class Pessoa{
    constructor(codigo,nome,idade){
        this.codigo=codigo;
        this.nome=nome;
        this.idade=idade;

    }
}

module.exports=Pessoa;
