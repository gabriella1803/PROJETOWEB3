const express = require("express");
const res = require("express/lib/response");
const app = express();
app.use(express.urlencoded({extended:true}))
app.set("view engine","ejs");
app.use(express.static ("public"));

const Pessoa=require("./Pessoa");
p1= new Pessoa(1,"Gabi",12);
p2= new Pessoa(2,"Thalia",18);
p3= new Pessoa(3,"Jaily",14);

const lista=[]
lista.push(p1);
lista.push(p2);
lista.push(p3);
console.log(lista)

app.get("/",function(req,res){
    res.render("index")
})

app.get("/pessoa",function(req,res){
    res.render("pessoa",{lista});
});


app.get("/pessoa/cadastrar",function(req,res){
    res.render("cadastrar")
})

app.post("/pessoa", function(req, res){
    lista.push(req.body)
    res.redirect("/pessoa")  
});

app.get("/pessoa/:codigo", function(req,res){
    const codigo= req.params.codigo;
    let resultado;
    for(let i=0;i<lista.length;i++){
        const pessoa= lista [i];
        if(pessoa.codigo == codigo){
            resultado= pessoa ;
            break
        
    }
}
res.render ("pessoaunic",{resultado});
})


app.listen(999, function(){
    console.log("Servidor iniciado");
});






/*app.get("/clientes/:id?",function(req,res){
    const id = req.params.id;
    const cliente={
        nome: "Gabriella",
        idade:18,
        altura:1.65
    };
    if (id){
        res.send(` <b>Nome:</b> ${cliente.nome}</br> <b>Idade:</b> ${cliente.idade}</br> <b>Altura:</b> ${cliente.altura} </br>`)
    }
    else {
        res.send("ID invalido");
    }
 
    
});

app.get("/pedidos/cadastrar",function(req,res){
    const id= req.query.id;
    const quantidade= req.query.quantidade;
    const valor=req.query.valor
    res.send(valor);
    
});


app.listen(999, function(){
    console.log("Servidor iniciado");
});

*/